import { useEffect, useMemo, useRef, useState } from 'react';
import { Camera, Check, ImagePlus, MessageCircle, Reply, Send, Smile, X } from 'lucide-react';

type Profile = { id: string; name: string; avatar: string; verified?: boolean; username?: string };
type Message = { id: string; profileId: string; author: Profile; text: string; image?: string; replyToId?: string | null; reactions?: Record<string, number>; createdAt: number };
const REACTIONS = ['👍', '❤️', '😂', '🔥', '😮'];

function getProfileId() {
  const key = 'kaalix_community_profile_id';
  let id = localStorage.getItem(key);
  if (!id) { id = crypto.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`; localStorage.setItem(key, id); }
  return id;
}

export default function CommunityChat({ onClose }: { onClose: () => void }) {
  const [profileId] = useState(getProfileId);
  const [profile, setProfile] = useState<Profile>({ id: profileId, name: 'Guest', avatar: '/favicon-dp.jpg', verified: false });
  const [verificationLink, setVerificationLink] = useState('');
  const [verificationToken, setVerificationToken] = useState('');
  const [verificationBusy, setVerificationBusy] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [image, setImage] = useState('');
  const [editing, setEditing] = useState(false);
  const [draftName, setDraftName] = useState('');
  const [draftAvatar, setDraftAvatar] = useState('');
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const avatarRef = useRef<HTMLInputElement>(null);
  const messageById = useMemo(() => new Map(messages.map((m) => [m.id, m])), [messages]);

  const load = async (scroll = false) => {
    try {
      const response = await fetch(`/api/community?profileId=${encodeURIComponent(profileId)}`, { cache: 'no-store' });
      const data = await response.json();
      if (data?.ok) { setProfile(data.profile); setMessages(data.messages || []); if (scroll) setTimeout(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), 30); }
    } catch {}
  };
  useEffect(() => { load(true); const timer = window.setInterval(() => load(false), 2500); return () => window.clearInterval(timer); }, []);
  useEffect(() => {
    if (!verificationToken || profile.verified) return;
    const timer = window.setInterval(async () => {
      const response = await fetch('/api/community/verify/status', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ profileId, token: verificationToken }) });
      const data = await response.json();
      if (data?.verified) { setProfile(data.profile); setVerificationToken(''); setVerificationLink(''); }
    }, 2500);
    return () => window.clearInterval(timer);
  }, [verificationToken, profile.verified, profileId]);
  const startVerification = async () => {
    setVerificationBusy(true);
    try {
      const response = await fetch('/api/community/verify/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ profileId }) });
      const data = await response.json();
      if (data?.ok) { setVerificationLink(data.link); setVerificationToken(data.token); window.open(data.link, '_blank', 'noopener,noreferrer'); }
    } finally { setVerificationBusy(false); }
  };

  const saveProfile = async () => {
    const response = await fetch('/api/community/profile', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ profileId, name: draftName, avatar: draftAvatar }) });
    const data = await response.json();
    if (data?.ok) { setProfile(data.profile); setEditing(false); }
  };
  const readImage = (file: File, setter: (value: string) => void) => { if (!file.type.startsWith('image/')) return; const reader = new FileReader(); reader.onload = () => setter(String(reader.result || '')); reader.readAsDataURL(file); };
  const sendMessage = async () => {
    if ((!text.trim() && !image) || sending) return;
    setSending(true);
    try {
      const response = await fetch('/api/community/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ profileId, text, image, replyToId: replyTo?.id }) });
      const data = await response.json();
      if (data?.ok) { setMessages((current) => [...current, data.message]); setText(''); setImage(''); setReplyTo(null); setTimeout(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), 30); }
    } finally { setSending(false); }
  };
  const react = async (message: Message, emoji: string) => {
    const response = await fetch(`/api/community/messages/${message.id}/reaction`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ profileId, emoji }) });
    const data = await response.json();
    if (data?.ok) setMessages((current) => current.map((item) => item.id === message.id ? { ...item, reactions: data.reactions } : item));
  };
  const startEdit = () => { setDraftName(profile.name); setDraftAvatar(profile.avatar); setEditing(true); };

  return <div className="community-overlay" onClick={(event) => event.target === event.currentTarget && onClose()}>
    <section className="community-modal" aria-label="Kaalix community group chat">
      <header className="community-header">
        <div className="community-title"><div className="community-icon"><MessageCircle size={20} /></div><div><h2>Community Chat</h2><p><span className="community-live-dot" /> Live group · everyone is welcome</p></div></div>
        <div className="community-header-actions"><button className="community-avatar-button" onClick={startEdit} title="Edit your profile"><img src={profile.avatar} alt="Your profile" /></button><button className="community-close" onClick={onClose}><X size={18} /></button></div>
      </header>
      {editing && <div className="community-profile-editor"><div className="community-editor-avatar"><img src={draftAvatar || '/favicon-dp.jpg'} alt="Preview" /><button onClick={() => avatarRef.current?.click()}><Camera size={14} /></button><input ref={avatarRef} type="file" accept="image/*" hidden onChange={(event) => event.target.files?.[0] && readImage(event.target.files[0], setDraftAvatar)} /></div><input value={draftName} onChange={(event) => setDraftName(event.target.value)} maxLength={32} placeholder="Display name" /><button onClick={saveProfile} className="community-save"><Check size={14} /> Save profile</button></div>}
      {!profile.verified && <div className="community-verify-banner"><div><strong>Verify your Telegram profile</strong><span>Start the bot once so your real name, username and DP can be attached to your messages.</span></div><button onClick={startVerification} disabled={verificationBusy}>{verificationBusy ? 'Preparing…' : verificationLink ? 'Open bot again' : 'Verify with Telegram'} <Send size={13} /></button>{verificationLink && <small>After pressing Start in Telegram, return here — verification updates automatically.</small>}</div>}
      <div className="community-messages">{messages.length === 0 && <div className="community-empty"><MessageCircle size={30} /><strong>Start the conversation</strong><span>Messages sent here are saved live for the group.</span></div>}{messages.map((message) => { const quoted = message.replyToId ? messageById.get(message.replyToId) : null; const own = message.profileId === profileId; return <article className={`community-message ${own ? 'is-own' : ''}`} key={message.id}><img className="community-message-avatar" src={message.author.avatar || '/favicon-dp.jpg'} alt="" /><div className="community-message-body"><div className="community-message-meta"><b>{message.author.name}</b><time>{new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time></div>{quoted && <div className="community-quoted"><Reply size={12} /> {quoted.author.name}: {quoted.text || 'Photo'}</div>}{message.text && <p>{message.text}</p>}{message.image && <img className="community-message-image" src={message.image} alt="Shared by community member" />}{<div className="community-message-tools"><button disabled={!profile.verified} onClick={() => setReplyTo(message)}><Reply size={13} /> Reply</button><div className="community-reactions">{REACTIONS.map((emoji) => <button key={emoji} onClick={() => react(message, emoji)} className={(message.reactions?.[emoji] || 0) > 0 ? 'has-reaction' : ''}>{emoji}{(message.reactions?.[emoji] || 0) > 0 && <small>{message.reactions?.[emoji]}</small>}</button>)}</div></div>}</div></article>; })}<div ref={endRef} /></div>
      {replyTo && <div className="community-reply-bar"><Reply size={14} /><span>Replying to <b>{replyTo.author.name}</b>: {replyTo.text || 'Photo'}</span><button onClick={() => setReplyTo(null)}><X size={14} /></button></div>}
      {image && <div className="community-attachment"><img src={image} alt="Attachment preview" /><button onClick={() => setImage('')}><X size={14} /></button></div>}
      <footer className="community-composer"><button disabled={!profile.verified} className="community-tool" onClick={() => fileRef.current?.click()} title="Send photo"><ImagePlus size={19} /></button><input ref={fileRef} type="file" disabled={!profile.verified} accept="image/*" hidden onChange={(event) => event.target.files?.[0] && readImage(event.target.files[0], setImage)} /><input disabled={!profile.verified} value={text} onChange={(event) => setText(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendMessage(); } }} placeholder="Write a message..." maxLength={1200} /><button disabled={!profile.verified} className="community-tool" title="Emoji" onClick={() => setText((value) => `${value} 🙂`)}><Smile size={18} /></button><button disabled={!profile.verified || sending || (!text.trim() && !image)} className="community-send" onClick={sendMessage}><Send size={17} /></button></footer>
      <div className="community-footnote">Your profile is created automatically. Verify with Telegram before sending messages.</div>
    </section>
  </div>;
}
