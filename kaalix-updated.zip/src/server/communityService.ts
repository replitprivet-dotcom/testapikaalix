import { createHash, randomUUID } from 'crypto';
import { Db, MongoClient } from 'mongodb';
import { TELEGRAM_BOT_TOKEN } from './telegramProfileService';

const MONGO_URI = process.env.MONGODB_URI || process.env.MONGO_URI || '';
const DB_NAME = process.env.MONGODB_DB || 'kaalix_db';
const TELEGRAM_BOT_USERNAME = process.env.TELEGRAM_BOT_USERNAME || '';
let cachedClient: MongoClient | null = null;
let cachedDb: Db | null = null;

async function getDb(): Promise<Db> {
  if (!MONGO_URI) throw new Error('Community database is not configured');
  if (cachedDb && cachedClient) return cachedDb;
  const client = new MongoClient(MONGO_URI, { serverSelectionTimeoutMS: 5000, connectTimeoutMS: 10000, maxPoolSize: 10 });
  await client.connect();
  cachedClient = client;
  cachedDb = client.db(DB_NAME);
  return cachedDb;
}
function cleanText(value: unknown, max: number): string { return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max); }
export function hashIp(ip: string): string { return createHash('sha256').update(`${process.env.MONGODB_IP_SALT || 'kaalix-community'}:${ip}`).digest('hex').slice(0, 24); }
export interface CommunityProfile { id: string; name: string; avatar: string; verified: boolean; telegramId?: string; username?: string; createdAt: number; updatedAt: number; }
function defaultProfile(id: string): CommunityProfile { return { id, name: `Guest ${id.slice(-4).toUpperCase()}`, avatar: '/favicon-dp.jpg', verified: false, createdAt: Date.now(), updatedAt: Date.now() }; }
function publicProfile(profile: any): CommunityProfile { return { id: profile.id, name: profile.name, avatar: profile.avatar, verified: Boolean(profile.verified), telegramId: profile.telegramId, username: profile.username, createdAt: profile.createdAt, updatedAt: profile.updatedAt }; }

export async function getOrCreateProfile(profileId: string | undefined, ip: string, userAgent = ''): Promise<CommunityProfile> {
  const db = await getDb(); const profiles = db.collection<any>('community_profiles'); const id = cleanText(profileId, 80) || randomUUID(); const ipHash = hashIp(ip);
  const existing = await profiles.findOne({ id });
  if (existing) { await profiles.updateOne({ id }, { $set: { ipHash, userAgent: cleanText(userAgent, 240), lastSeenAt: Date.now() } }); return publicProfile(existing); }
  const profile = defaultProfile(id); await profiles.insertOne({ ...profile, ipHash, userAgent: cleanText(userAgent, 240), lastSeenAt: Date.now() }); return profile;
}
export async function updateProfile(profileId: string, ip: string, patch: { name?: string; avatar?: string }): Promise<CommunityProfile> {
  const db = await getDb(); const profiles = db.collection<any>('community_profiles'); const current = await profiles.findOne({ id: cleanText(profileId, 80) });
  if (!current) return getOrCreateProfile(profileId, ip);
  const name = cleanText(patch.name, 32) || current.name; const avatar = typeof patch.avatar === 'string' && (patch.avatar.startsWith('/') || patch.avatar.startsWith('data:image/')) ? patch.avatar.slice(0, 2_000_000) : current.avatar;
  await profiles.updateOne({ id: current.id }, { $set: { name, avatar, updatedAt: Date.now(), ipHash: hashIp(ip) } }); return publicProfile({ ...current, name, avatar, updatedAt: Date.now() });
}

export async function startCommunityVerification(profileId: string, ip: string, origin: string) {
  if (!TELEGRAM_BOT_TOKEN) throw new Error('Telegram verification is not configured');
  const db = await getDb(); const profile = await getOrCreateProfile(profileId, ip); const token = randomUUID().replace(/-/g, '');
  const botRes = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe`, { signal: AbortSignal.timeout(8000) }); const botData: any = await botRes.json();
  const username = TELEGRAM_BOT_USERNAME || botData?.result?.username; if (!username) throw new Error('Telegram bot username is not available');
  await db.collection('community_verifications').insertOne({ token, profileId: profile.id, ipHash: hashIp(ip), status: 'pending', createdAt: Date.now(), expiresAt: Date.now() + 10 * 60 * 1000 });
  if (origin) await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook?url=${encodeURIComponent(`${origin}/api/telegram/webhook`)}`, { signal: AbortSignal.timeout(8000) }).catch(() => {});
  return { token, link: `https://t.me/${username}?start=kaalix_${token}`, expiresAt: Date.now() + 10 * 60 * 1000 };
}
export async function getCommunityVerification(profileId: string, token: string, ip: string) {
  const db = await getDb(); const record = await db.collection<any>('community_verifications').findOne({ token: cleanText(token, 80), profileId: cleanText(profileId, 80), ipHash: hashIp(ip), expiresAt: { $gt: Date.now() } });
  const profile = await getOrCreateProfile(profileId, ip); return { verified: Boolean(record?.status === 'verified' && profile.verified), profile };
}
export async function processTelegramVerificationUpdate(update: any) {
  const message = update?.message; const raw = typeof message?.text === 'string' ? message.text : ''; const match = raw.match(/^\/start(?:\s+kaalix_([a-zA-Z0-9]+))?/);
  if (!match?.[1] || !message?.from?.id || !TELEGRAM_BOT_TOKEN) return { ok: true, handled: false };
  const db = await getDb(); const verification = await db.collection<any>('community_verifications').findOne({ token: match[1], status: 'pending', expiresAt: { $gt: Date.now() } }); if (!verification) return { ok: true, handled: false };
  const user = message.from; const name = [user.first_name, user.last_name].filter(Boolean).join(' ') || `Telegram ${user.id}`; const username = user.username ? `@${user.username}` : '';
  await db.collection('community_profiles').updateOne({ id: verification.profileId }, { $set: { name, username, telegramId: String(user.id), verified: true, avatar: `/api/telegram/verified-avatar?user_id=${encodeURIComponent(user.id)}`, updatedAt: Date.now() } });
  await db.collection('community_verifications').updateOne({ token: match[1] }, { $set: { status: 'verified', telegramId: String(user.id), verifiedAt: Date.now() } });
  await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage?chat_id=${encodeURIComponent(user.id)}&text=${encodeURIComponent('Verified. You can return to Kaalix Community Chat now.')}`, { signal: AbortSignal.timeout(8000) }).catch(() => {});
  return { ok: true, handled: true };
}

export async function listMessages(limit = 80): Promise<any[]> { const db = await getDb(); const docs = await db.collection('community_messages').find({ deleted: { $ne: true } }).sort({ createdAt: -1 }).limit(Math.min(limit, 100)).toArray(); return docs.reverse().map(({ _id, ...message }) => message); }
export async function createMessage(profileId: string, ip: string, text: string, image?: string, replyToId?: string): Promise<any> { const db = await getDb(); const profile = await getOrCreateProfile(profileId, ip); if (!profile.verified) throw new Error('Verify your Telegram profile before sending messages'); const cleanMessage = cleanText(text, 1200); const safeImage = typeof image === 'string' && image.startsWith('data:image/') ? image.slice(0, 2_000_000) : ''; if (!cleanMessage && !safeImage) throw new Error('Message cannot be empty'); const message = { id: randomUUID(), profileId: profile.id, author: { name: profile.name, avatar: profile.avatar, username: profile.username }, text: cleanMessage, image: safeImage, replyToId: cleanText(replyToId, 80) || null, reactions: {}, createdAt: Date.now() }; await db.collection('community_messages').insertOne(message); return message; }
export async function reactToMessage(messageId: string, profileId: string, emoji: string): Promise<any> { const allowed = ['👍', '❤️', '😂', '🔥', '😮']; if (!allowed.includes(emoji)) throw new Error('Unsupported reaction'); const db = await getDb(); const messages = db.collection<any>('community_messages'); const profile = await getOrCreateProfile(profileId, 'reaction'); if (!profile.verified) throw new Error('Verify your Telegram profile before reacting'); const message = await messages.findOne({ id: cleanText(messageId, 80) }); if (!message) throw new Error('Message not found'); const current = Array.isArray(message.reactionUsers?.[emoji]) ? message.reactionUsers[emoji] : []; const next = current.includes(profileId) ? current.filter((id: string) => id !== profileId) : [...current, profileId].slice(-500); const reactionUsers = { ...(message.reactionUsers || {}), [emoji]: next }; const reactions = Object.fromEntries(Object.entries(reactionUsers).map(([key, users]) => [key, (users as string[]).length])); await messages.updateOne({ id: message.id }, { $set: { reactionUsers, reactions } }); return { id: message.id, reactions }; }
