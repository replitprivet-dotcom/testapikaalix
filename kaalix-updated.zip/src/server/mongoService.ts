import { MongoClient, Db } from 'mongodb';
import { hashIp } from './communityService';

const MONGO_URI = process.env.MONGODB_URI || process.env.MONGO_URI || '';
const DB_NAME = process.env.MONGODB_DB || 'kaalix_db';

let cachedClient: MongoClient | null = null;
let cachedDb: Db | null = null;

async function getDb(): Promise<Db> {
  if (cachedDb && cachedClient) {
    return cachedDb;
  }

  if (!MONGO_URI) throw new Error('Analytics database is not configured');
  const client = new MongoClient(MONGO_URI, {
    serverSelectionTimeoutMS: 5000,
    connectTimeoutMS: 10000,
    maxPoolSize: 10,
  });

  await client.connect();
  cachedClient = client;
  cachedDb = client.db(DB_NAME);
  return cachedDb;
}

export interface EndpointRatingDoc {
  endpoint: string;
  totalScore: number;
  count: number;
  average: number;
  lastUpdated: number;
}

export interface AnalyticsData {
  total_visitors: number;
  total_views: number;
  total_api_requests: number;
  total_ratings_count: number;
  overall_average_rating: number;
  top_endpoints: Array<{ endpoint: string; calls: number }>;
  top_rated_endpoints: Array<{ endpoint: string; average: number; count: number }>;
  server_time: number;
}

// 1. Record Website Visit (page load)
export async function trackVisit(ip = 'unknown', userAgent = ''): Promise<{ views: number; visitors: number }> {
  try {
    const db = await getDb();
    const statsCol = db.collection('site_analytics');
    const visitorsCol = db.collection('unique_visitors');

    const today = new Date().toISOString().slice(0, 10);
    const visitorKey = `${ip}_${today}`;

    // Mark unique visitor today
    const isNewVisitor = await visitorsCol.updateOne(
      { key: visitorKey },
      { $setOnInsert: { key: visitorKey, ip, userAgent, date: today, createdAt: Date.now() } },
      { upsert: true }
    );

    const incQuery: any = { total_views: 1 };
    if (isNewVisitor.upsertedCount > 0) {
      incQuery.total_visitors = 1;
    }

    const res = await statsCol.findOneAndUpdate(
      { id: 'global_stats' },
      { $inc: incQuery, $setOnInsert: { createdAt: Date.now() } },
      { upsert: true, returnDocument: 'after' }
    );

    return {
      views: res?.total_views || 0,
      visitors: res?.total_visitors || 0,
    };
  } catch (err) {
    console.warn('[MongoDB] trackVisit warning:', err);
    return { views: 0, visitors: 0 };
  }
}

// 2. Track API Request Call
export async function trackApiCall(endpoint: string, method = 'GET', status = 200) {
  try {
    const db = await getDb();
    const statsCol = db.collection('site_analytics');
    const endpointCallsCol = db.collection('endpoint_calls');

    // Global requests counter
    await statsCol.updateOne(
      { id: 'global_stats' },
      { $inc: { total_api_requests: 1 } },
      { upsert: true }
    );

    // Endpoint specific counter
    const cleanPath = endpoint.split('?')[0];
    await endpointCallsCol.updateOne(
      { endpoint: cleanPath },
      { $inc: { calls: 1 }, $set: { lastMethod: method, lastStatus: status, lastCalledAt: Date.now() } },
      { upsert: true }
    );
  } catch (err) {
    console.warn('[MongoDB] trackApiCall warning:', err);
  }
}

// 3. Save Real Rating to MongoDB
export async function submitRealRating(endpoint: string, stars: number, ip = 'unknown'): Promise<{ success: boolean; data?: EndpointRatingDoc }> {
  try {
    if (!endpoint.trim() || !Number.isInteger(stars) || stars < 1 || stars > 5) throw new Error('Endpoint and stars (1-5) are required');
    const db = await getDb();
    const ratingsCol = db.collection('ratings');
    const votesCol = db.collection('rating_votes');
    const cleanPath = endpoint.trim().slice(0, 300);
    const voterKey = `${hashIp(ip)}:${cleanPath}`;
    const previous = await votesCol.findOne({ voterKey });
    if (previous) {
      await votesCol.updateOne({ voterKey }, { $set: { stars, updatedAt: Date.now() } });
      await ratingsCol.updateOne({ endpoint: cleanPath }, { $inc: { totalScore: stars - Number(previous.stars || 0) }, $set: { lastUpdated: Date.now() } });
    } else {
      await votesCol.insertOne({ voterKey, endpoint: cleanPath, stars, createdAt: Date.now(), updatedAt: Date.now() });
      await ratingsCol.updateOne({ endpoint: cleanPath }, { $inc: { totalScore: stars, count: 1 }, $set: { lastUpdated: Date.now() }, $setOnInsert: { endpoint: cleanPath } }, { upsert: true });
      await db.collection('site_analytics').updateOne({ id: 'global_stats' }, { $inc: { total_ratings_count: 1 } }, { upsert: true });
    }
    const aggregate = await votesCol.aggregate([{ $match: { endpoint: cleanPath } }, { $group: { _id: '$endpoint', totalScore: { $sum: '$stars' }, count: { $sum: 1 } } }]).next();
    const totalScore = Number(aggregate?.totalScore || 0);
    const count = Number(aggregate?.count || 0);
    const updatedDoc: EndpointRatingDoc = { endpoint: cleanPath, totalScore, count, average: count ? Number((totalScore / count).toFixed(1)) : 0, lastUpdated: Date.now() };
    await ratingsCol.updateOne({ endpoint: cleanPath }, { $set: updatedDoc }, { upsert: true });
    return { success: true, data: updatedDoc };
  } catch (err) {
    console.error('[MongoDB] submitRealRating error:', err);
    return { success: false };
  }
}

// 4. Get All Real Ratings from MongoDB
export async function fetchAllRealRatings(): Promise<Record<string, { score: number; count: number }>> {
  try {
    const db = await getDb();
    const ratingsCol = db.collection('ratings');
    const docs = await ratingsCol.find({}).toArray();

    const map: Record<string, { score: number; count: number }> = {};
    for (const doc of docs) {
      if (doc.endpoint) {
        map[doc.endpoint] = {
          score: doc.average || 0,
          count: doc.count || 0,
        };
      }
    }
    return map;
  } catch (err) {
    console.warn('[MongoDB] fetchAllRealRatings warning:', err);
    return {};
  }
}

// 5. Get Analytics Summary for Dashboard
export async function fetchAnalyticsData(): Promise<AnalyticsData> {
  try {
    const db = await getDb();
    const statsCol = db.collection('site_analytics');
    const endpointCallsCol = db.collection('endpoint_calls');
    const ratingsCol = db.collection('ratings');

    const globalStats: any = (await statsCol.findOne({ id: 'global_stats' })) || {};

    const topCalls = await endpointCallsCol
      .find({})
      .sort({ calls: -1 })
      .limit(8)
      .toArray();

    const topRated = await ratingsCol
      .find({})
      .sort({ average: -1, count: -1 })
      .limit(8)
      .toArray();

    // Calculate real community average across all ratings
    const allRatings = await ratingsCol.find({}).toArray();
    let totalScoreSum = 0;
    let totalCountSum = 0;
    for (const r of allRatings) {
      totalScoreSum += r.totalScore || 0;
      totalCountSum += r.count || 0;
    }
    const overallAvg = totalCountSum > 0 ? parseFloat((totalScoreSum / totalCountSum).toFixed(1)) : 0;

    return {
      total_visitors: globalStats.total_visitors || 0,
      total_views: globalStats.total_views || 0,
      total_api_requests: globalStats.total_api_requests || 0,
      total_ratings_count: totalCountSum,
      overall_average_rating: totalCountSum > 0 ? overallAvg : 0,
      top_endpoints: topCalls.map((c) => ({ endpoint: c.endpoint, calls: c.calls })),
      top_rated_endpoints: topRated.map((r) => ({ endpoint: r.endpoint, average: r.average, count: r.count })),
      server_time: Date.now(),
    };
  } catch (err) {
    console.warn('[MongoDB] fetchAnalyticsData warning:', err);
    return {
      total_visitors: 0,
      total_views: 0,
      total_api_requests: 0,
      total_ratings_count: 0,
      overall_average_rating: 0,
      top_endpoints: [],
      top_rated_endpoints: [],
      server_time: Date.now(),
    };
  }
}
